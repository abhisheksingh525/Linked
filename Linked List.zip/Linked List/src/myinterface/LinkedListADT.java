package myinterface;

public interface LinkedListADT {
    boolean addLast(float element);
    int size();
    boolean isEmpty();
    float sum();
    float mean();

}
